package com.lms.attendanceservice.constants;

import lombok.ToString;

@ToString
public class ResponseStatus {
    public static String SUCCESS = "SUCCESS";
    public static String FAILED = "FAILED";
}
